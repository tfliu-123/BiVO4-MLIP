#!/bin/bash
#phonopy -d --dim='4 4 4'
for i in {95..105}
do      
	        #/bin/mkdir $i
		        #/bin/mv POSCAR-$i  $i/POSCAR
	#/bin/cp INCAR KPOINTS POTCAR vasp.pbs $i/
	cd  $i/
	qsub vasp.pbs
	cd  ../
	#/bin/cp $i/vasprun.xml   ./V-$i
done
#phonopy -f V-001 V-002 V-003 V-004 V-005 V-006 V-007 V-008 V-009 V-010
#phonopy -p  band.confby
#phonopy -t -p mesh.conf
#phonopy --dim="4 4 2" --fc-symmetry --mesh="4 4 2" --gamma-center
