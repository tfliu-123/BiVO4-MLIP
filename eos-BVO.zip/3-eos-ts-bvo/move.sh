#!/bin/bash
#phonopy -d --dim='4 4 2'
for i in {95..105}
do      
	#        /bin/mkdir $i
	#	        /bin/mv CONTCAR-103-$i  $i/
	#/bin/cp INCAR   vasp.pbs $i/
  #/bin/cp INCAR  vasp.pbs $i/
	cd $i/
      #/bin/cp CONTCAR-103-$i   POSCAR
       /bin/rm  WAVECAR
	#grep 'TOTEN' OUTCAR | tail -1 > Eo-$i.dat
	#grep 'volume of cell' OUTCAR |tail -1 > Vo-$i.dat 
	#/bin/cp Eo-$i.dat Vo-$i.dat ../
	cd  ../
#/bin/cp $i/vasprun.xml   ./V-$i
done
#cat Eo-{95..105}.dat > Eo.dat
#cat Vo-{95..105}.dat > Vo.dat
#phonopy -f V-001 V-002 V-003 V-004 V-005 V-006 V-007 V-008 V-009 V-010
#phonopy -p  band.confby
#phonopy -t -p mesh.conf
#phonopy --dim="4 4 2" --fc-symmetry --mesh="4 4 2" --gamma-center
